//
//  AppColor.swift
//  homefinancing
//
//  Created by 辰 宫 on 16/2/20.
//  Copyright © 2016年 wph. All rights reserved.
//

let appPayColor = UIColor(red: 62/255, green: 187/255, blue: 157/255, alpha: 1.0);

let appLitePayColor = UIColor(red: 62/255, green: 187/255, blue: 157/255, alpha: 0.3);

let appIncomeColor = UIColor(red: 245/255, green: 166/255, blue: 40/255, alpha: 1.0);

let appDarkBackgroundColor = UIColor(red: 55/255, green: 78/255, blue: 97/255, alpha: 1.0);

let appDarkBackgroundColor_lite = UIColor(red: 70/255, green: 97/255, blue: 116/255, alpha: 1.0);

let appGrayTextColor = UIColor(red: 153/255, green: 153/255, blue: 153/255, alpha: 1.0);
