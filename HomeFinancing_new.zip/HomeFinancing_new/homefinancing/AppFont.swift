//
//  AppFont.swift
//  homefinancing
//
//  Created by 辰 宫 on 4/6/16.
//  Copyright © 2016 wph. All rights reserved.
//

func AppFont(size:CGFloat) -> UIFont {
    return UIFont.systemFontOfSize(size)
}
