//
//  AccountGroupStruct.swift
//  homefinancing
//
//  Created by 辰 宫 on 5/11/16.
//  Copyright © 2016 wph. All rights reserved.
//

struct AccountGroupStruct {
    var payAmount: String?
    var incomeAmount: String?
    let centerDateStr: String
    let dayDateStr: String
    var accountModelArray: Array<AccountModel>
}
