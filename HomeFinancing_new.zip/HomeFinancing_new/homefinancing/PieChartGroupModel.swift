//
//  PieChartGroupModel.swift
//  homefinancing
//
//  Created by 辰 宫 on 5/15/16.
//  Copyright © 2016 wph. All rights reserved.
//

class PieChartGroupModel: GCDBModel {
    var typeId:String?
    var typeName:String?
}
