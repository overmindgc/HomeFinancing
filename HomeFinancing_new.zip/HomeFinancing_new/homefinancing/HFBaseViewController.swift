//
//  HFBaseViewController.swift
//  homefinancing
//
//  Created by 辰 宫 on 3/17/16.
//  Copyright © 2016 wph. All rights reserved.
//

class HFBaseViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()

        
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    

}
