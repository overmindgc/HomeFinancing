//
//  AppNotificationConts.swift
//  homefinancing
//
//  Created by 辰 宫 on 16/5/11.
//  Copyright © 2016年 wph. All rights reserved.
//

let CREATE_UPDATE_DEL_ACCOUNT_SUCCESS_NOTICATION = "createUpdateDelAccountSuccessNotification"

let CHANGE_MONTH_BUDGET_NUM_SUCCESS_NOTIFICATION = "changeMonthBudgetNumSuccessNotification"