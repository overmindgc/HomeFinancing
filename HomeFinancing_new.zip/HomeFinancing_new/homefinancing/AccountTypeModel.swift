//
//  AccountTypeModel.swift
//  homefinancing
//
//  Created by 辰 宫 on 5/8/16.
//  Copyright © 2016 wph. All rights reserved.
//

class AccountTypeModel: GCDBModel {
    var id:String?
    var name:String?
}
