//
//  LineChartStatisticViewController.swift
//  homefinancing
//
//  Created by 辰 宫 on 5/18/16.
//  Copyright © 2016 wph. All rights reserved.
//

class LineChartStatisticViewController: HFBaseViewController,UITableViewDelegate,UITableViewDataSource {

    let tableCellIndentifier = "tableCellIndentifier"
    
    @IBOutlet weak var topTitleLabel: UILabel!
    
    @IBOutlet weak var avgPayValueLabel: UILabel!
    @IBOutlet weak var avgIncomeValueLabel: UILabel!
    @IBOutlet weak var yearLeftLabel: UILabel!
    
    @IBOutlet weak var sepLineView: UIView!
    
    private var lineChartView: PNLineChart?
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        let chartHeight:CGFloat = (SCREEN_HEIGHT - sepLineView.frame.origin.y - 44) / 2
        
        lineChartView = PNLineChart(frame:CGRectMake(0,sepLineView.frame.origin.y - 50,SCREEN_WIDTH,chartHeight))
        lineChartView?.yLabelFormat = "%1.f"
        lineChartView?.axisColor = UIColor.grayColor()
        lineChartView?.xLabelColor = UIColor.grayColor()
        lineChartView?.yLabelColor = UIColor.grayColor()
        lineChartView?.backgroundColor = UIColor.whiteColor()
        lineChartView?.setXLabels(["1月","","3月","","5月","","7月","","9月","","11月",""], withWidth: 25)
        lineChartView?.showCoordinateAxis = true
//        lineChartView?.chartMarginLeft = 0
        lineChartView?.chartMarginRight = 5
        
        lineChartView?.legendStyle = PNLegendItemStyle.Serial
        lineChartView?.legendFont = UIFont.boldSystemFontOfSize(12)
        lineChartView?.legendFontColor = UIColor.grayColor()
        self.view.addSubview(lineChartView!)
        
        let payDataArray = [4000, 5000, 5500, 3500, 1000, 4500, 6000, 6600, 5000, 4500, 5000, 6500]
        let payLineData = PNLineChartData()
        payLineData.dataTitle = "支出"
        payLineData.color = appPayColor
        payLineData.alpha = 0.6
        payLineData.itemCount = UInt(payDataArray.count)
        payLineData.inflexionPointStyle = PNLineChartPointStyle.Triangle
        payLineData.getData = { (index) in
            let yValue:CGFloat = CGFloat(payDataArray[Int(index)])
            return PNLineChartDataItem(y: yValue,andRawY: yValue)
        }
        
        let incomeDataArray = [7000, 8000, 8000, 8500, 8000, 8500, 8000, 8600, 8000, 8500, 8000, 8500]
        let incomeLineData = PNLineChartData()
        incomeLineData.dataTitle = "收入"
        incomeLineData.color = appIncomeColor
        incomeLineData.alpha = 0.6
        incomeLineData.itemCount = UInt(incomeDataArray.count)
        incomeLineData.inflexionPointStyle = PNLineChartPointStyle.Triangle
        incomeLineData.getData = { (index) in
            let yValue:CGFloat = CGFloat(incomeDataArray[Int(index)])
            return PNLineChartDataItem(y: yValue,andRawY: yValue)
        }
        
        lineChartView?.chartData = [payLineData,incomeLineData]
        lineChartView?.strokeChart()

        let legendView = lineChartView?.getLegendWithMaxWidth(420)
        legendView?.frame = CGRectMake(30, lineChartView!.frame.origin.y + chartHeight, legendView!.frame.size.width, legendView!.frame.size.height)
        self.view.addSubview(legendView!)
        
        let tableY = sepLineView.frame.origin.y + chartHeight - 38
        let tableView:UITableView = UITableView(frame: CGRectMake(0,tableY,SCREEN_WIDTH,chartHeight))
        tableView.delegate = self
        tableView.dataSource = self
        
        self.view.addSubview(tableView)
        
        
        refreshChartData()
    }
    
    func refreshChartData() {
//        var payOrIncome:String?
//        if payIncomeSegmemted.selectedSegmentIndex == 0 {
//            payOrIncome = String(AccountType.pay)
//        } else {
//            payOrIncome = String(AccountType.income)
//        }
//        let sourceArray = ChartStorageService.sharedInstance.getPieChartData(currentMonthStr, yearStr: currentYearStr, memberId: currentMemberId, payOrIncome: payOrIncome).array
//        
//        var items:[PNPieChartDataItem] = []
//        for pieGroupModel in sourceArray! {
//            let sum:Float = Float(pieGroupModel.sum_result)!
//            let item = PNPieChartDataItem()
//            item.color = randomColor(hue: .Random, luminosity: .Bright)
//            item.value = CGFloat(sum)
//            item.textDescription = pieGroupModel.typeName
//            items.append(item)
//        }
//        if items.count > 0 {
//            pieChartView.updateChartData(items)
//            
//            let legend = pieChartView.getLegendWithMaxWidth(SCREEN_WIDTH * 0.9)
//            legend.frame = CGRectMake(SCREEN_WIDTH/2 - legend.frame.size.width/2, 450, legend.frame.size.width, legend.frame.size.height)
//            self.view.addSubview(legend)
//        }
//        
    }

    // MARK: - TableView
    func numberOfSectionsInTableView(tableView: UITableView) -> Int {
        return 1
    }
    //每一块有多少行
    func tableView(tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return 12
    }
    //绘制cell
    func tableView(tableView: UITableView, cellForRowAtIndexPath indexPath: NSIndexPath) -> UITableViewCell {
        let section = indexPath.section
        let row = indexPath.row
        
//        let itemCell = HomeItemCell(style: UITableViewCellStyle.Default, reuseIdentifier: tableCellIndentifier)
//        itemCell.accessoryType = UITableViewCellAccessoryType.None
//        let groupStruct:AccountGroupStruct = tableSource[section]
//        let accountModel = groupStruct.accountModelArray[row]
//        if accountModel.payOrIncome == String(AccountType.pay) {
//            itemCell.currentType = AccountType.pay
//            itemCell.payLabel.text = "￥" + accountModel.amount! + " " + accountModel.typeName!
//        } else {
//            itemCell.currentType = AccountType.income
//            itemCell.incomeLabel.text = accountModel.typeName! + " " + "￥" + accountModel.amount!
//        }
//        if section == tableSource.count - 1 && row == groupStruct.accountModelArray.count - 1{
//            itemCell.hideButtomVLine = true
//        } else {
//            itemCell.hideButtomVLine = false
//        }
        return UITableViewCell()
    }
    
    func tableView(tableView: UITableView, didSelectRowAtIndexPath indexPath: NSIndexPath) {
        let currCell:HFTableViewCell = tableView.cellForRowAtIndexPath(indexPath) as! HFTableViewCell
        currCell.selected = false
    }
    
    //每个cell的高度
    func tableView(tableView: UITableView, heightForRowAtIndexPath indexPath: NSIndexPath) -> CGFloat {
        return 44
    }
    
    func tableView(tableView: UITableView, heightForHeaderInSection section: Int) -> CGFloat {
        return 30
    }
    
//    func tableView(tableView: UITableView, viewForHeaderInSection section: Int) -> UIView? {
//        let groupStruct:AccountGroupStruct = tableSource[section]
//        let headerView:HomeDateHeaderView = HomeDateHeaderView(frame:CGRectMake(0,0,HomeDateHeaderView.dateCellHeight,SCREEN_WIDTH))
//        headerView.payMoneyLabel.text = "￥" + groupStruct.payAmount!
//        headerView.incomeMoneyLabel.text = "￥" + groupStruct.incomeAmount!
//        headerView.dateLabel.text = groupStruct.centerDateStr
//        return headerView
//    }
    
    //MARK: - Actions
    
    @IBAction func lastClickAction(sender: AnyObject) {
    }
    
    @IBAction func nextClickAction(sender: AnyObject) {
    }
}
