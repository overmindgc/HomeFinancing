//
//  AppConsts.swift
//  homefinancing
//
//  Created by 辰 宫 on 4/6/16.
//  Copyright © 2016 wph. All rights reserved.
//

let SCREEN_WIDTH = UIScreen.mainScreen().bounds.size.width
let SCREEN_HEIGHT = UIScreen.mainScreen().bounds.size.height
let SCREEN_SCALE = UIScreen.mainScreen().scale

let NUM_STRING_POOL = ["0","1","2","3","4","5","6","7","8","9"]