//
//  MenberModel.swift
//  homefinancing
//
//  Created by 辰 宫 on 5/14/16.
//  Copyright © 2016 wph. All rights reserved.
//

class MemberModel: GCDBModel {
    var id:String?
    var name:String?
    var totalPay:String?
}
