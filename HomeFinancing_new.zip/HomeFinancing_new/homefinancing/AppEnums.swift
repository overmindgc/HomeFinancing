//
//  AppEnums.swift
//  homefinancing
//
//  Created by 辰 宫 on 5/7/16.
//  Copyright © 2016 wph. All rights reserved.
//

enum AccountType: String {
    case pay = "pay"
    case income = "income"
}
